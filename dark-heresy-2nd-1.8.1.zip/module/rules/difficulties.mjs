export function rollDifficulties() {
    return {
        '0': 'Challenging (+0)',
        '40': 'Simple (+40)',
        '30': 'Easy (+30)',
        '20': 'Routine (+20)',
        '10': 'Ordinary (+10)',
        '-10': 'Difficult (-10)',
        '-20': 'Hard (-20)',
        '-30': 'Very Difficult (-30)',
        '-40': 'Arduous (-40)',
    };
}
